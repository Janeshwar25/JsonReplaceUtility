# Sprint 17 — PlanName → plan_code

Added mapping:
Excel `PlanName` → JSON `plan_code`

Existing PlanName mappings remain:
- plan_name
- customer_plan_name

The JSON field is `plan_code` (not `plane_code`), verified against the supplied JSON.
The supplied Excel header is `PlanName`.
