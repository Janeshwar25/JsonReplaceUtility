# JsonReplaceUtility - Office User Guide

Put:
- `input\input.json`
- `input\OBMDataInput.xlsx`

First time:
```bat
install.bat
```

Recommended safe checks:
```bat
run_utility.bat --audit
run_utility.bat --preflight
run_utility.bat --dry-run
```

Real replacement:
```bat
run_utility.bat
```

Output:
`output\updated.json`

Backup:
`backup\`

Reports:
- mapping_audit.csv
- preflight_report.csv
- replacement_report.csv
- unmatched_fields.csv
- verification_report.csv
- performance_report.csv
- execution.log

For multiple Excel rows:
```bat
run_utility.bat --batch
```

`COC` is intentionally not mapped because no exact COC JSON target was identified in the supplied JSON.
