import logging
from pathlib import Path

class AppLogger:
    def __init__(self, log_file: Path):
        log_file.parent.mkdir(parents=True,exist_ok=True)
        self.log=logging.getLogger("JsonReplaceUtility")
        self.log.setLevel(logging.INFO)
        self.log.handlers.clear()
        h=logging.FileHandler(log_file,encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s | %(levelname)s | %(message)s"))
        self.log.addHandler(h)
    def info(self,msg): self.log.info(msg)
    def warning(self,msg): self.log.warning(msg)
    def error(self,msg): self.log.error(msg)
