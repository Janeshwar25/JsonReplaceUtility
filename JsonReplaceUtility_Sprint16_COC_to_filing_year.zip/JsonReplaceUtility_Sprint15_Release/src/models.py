from dataclasses import dataclass
from typing import Any

@dataclass(frozen=True)
class MappingRule:
    name: str
    excel_column: str
    targets: tuple[str,...]
    suffix_match: bool=False
    case_sensitive: bool=False
    conversion: str="match_existing"

@dataclass
class Replacement:
    path: str
    key: str
    old_value: Any
    new_value: Any
    excel_column: str
    rule: str
    row_number: int

@dataclass
class UnmatchedField:
    excel_column: str
    value: Any
    reason: str
    row_number: int

@dataclass
class RunStats:
    visited: int=0
    replacements: int=0
    unchanged_matches: int=0
    blank_values: int=0
    unmatched_rules: int=0
    collisions: int=0
    conversion_failures: int=0
