from collections import Counter
from .exceptions import MappingError

class Preflight:
    @staticmethod
    def key_inventory(data):
        counts=Counter()
        def walk(node):
            if isinstance(node,dict):
                for k,v in node.items():
                    counts[k]+=1
                    walk(v)
            elif isinstance(node,list):
                for item in node: walk(item)
        walk(data)
        return counts

    @staticmethod
    def analyze(data,rules):
        counts=Preflight.key_inventory(data)
        rows=[]
        for rule in rules:
            for target in rule.targets:
                matches=counts.get(target,0)
                status="MATCHED" if matches else "NOT_FOUND"
                rows.append([rule.name,rule.excel_column,target,matches,status])
        return rows

    @staticmethod
    def validate_configuration(data,rules):
        rows=Preflight.analyze(data,rules)
        missing=[r for r in rows if r[4]=="NOT_FOUND"]
        if missing:
            return False, rows
        return True, rows
