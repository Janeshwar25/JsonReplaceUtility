class UtilityError(Exception): pass
class ConfigurationError(UtilityError): pass
class ExcelError(UtilityError): pass
class JsonError(UtilityError): pass
class MappingError(UtilityError): pass
class ValidationError(UtilityError): pass
