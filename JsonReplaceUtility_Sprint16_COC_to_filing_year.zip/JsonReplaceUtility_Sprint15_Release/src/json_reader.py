from pathlib import Path
import orjson
from .exceptions import JsonError

class JsonReader:
    @staticmethod
    def load(path:Path):
        if not path.exists(): raise JsonError(f"JSON file not found: {path}")
        try: return orjson.loads(path.read_bytes())
        except Exception as exc: raise JsonError(f"Cannot load JSON {path}: {exc}") from exc

    @staticmethod
    def save(data,path:Path,pretty=True):
        path.parent.mkdir(parents=True,exist_ok=True)
        try: path.write_bytes(orjson.dumps(data,option=orjson.OPT_INDENT_2 if pretty else 0))
        except Exception as exc: raise JsonError(f"Cannot save JSON {path}: {exc}") from exc

    @staticmethod
    def structural_signature(v):
        # Values are intentionally excluded. A replacement is allowed to change
        # scalar values (and None -> concrete scalar) while keys/containers remain identical.
        if isinstance(v,dict):
            return ("dict",tuple((k,JsonReader.structural_signature(x)) for k,x in v.items()))
        if isinstance(v,list):
            return ("list",len(v),tuple(JsonReader.structural_signature(x) for x in v))
        return ("scalar",)
