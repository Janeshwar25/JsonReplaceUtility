from pathlib import Path
import copy
from .excel_reader import ExcelReader
from .json_reader import JsonReader
from .mapping_engine import MappingEngine
from .validator import Validator

class BatchProcessor:
    def __init__(self,json_path,excel_reader,config,logger):
        self.json_path=Path(json_path); self.excel_reader=excel_reader; self.config=config; self.logger=logger
    def run(self,output_dir,start_row=2,dry_run=False):
        template=JsonReader.load(self.json_path); output_dir=Path(output_dir); results=[]
        for row_number,row in self.excel_reader.iter_rows(start_row):
            try:
                working=copy.deepcopy(template)
                engine=MappingEngine(self.config.rules,row,row_number)
                engine.apply(working,dry_run)
                Validator.validate(template,working)
                output=output_dir/f"updated_row_{row_number}.json"
                if not dry_run: JsonReader.save(working,output,self.config.settings.get("pretty_json",True))
                results.append([row_number,"SUCCESS",engine.stats.replacements,engine.stats.unmatched_rules,str(output) if not dry_run else "DRY-RUN",""])
            except Exception as exc:
                self.logger.error(f"Row {row_number} failed: {exc}")
                results.append([row_number,"FAILED",0,0,"",str(exc)])
        return results
