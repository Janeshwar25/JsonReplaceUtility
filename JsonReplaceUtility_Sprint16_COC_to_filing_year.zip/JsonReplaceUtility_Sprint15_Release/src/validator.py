from .json_reader import JsonReader
from .exceptions import ValidationError

class Validator:
    @staticmethod
    def validate(before,after):
        if JsonReader.structural_signature(before)!=JsonReader.structural_signature(after):
            raise ValidationError("JSON structure changed: keys, object/list hierarchy, or list length differs")
