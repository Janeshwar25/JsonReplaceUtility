from typing import Any
from .models import MappingRule,Replacement,UnmatchedField,RunStats
from .exceptions import MappingError
from .value_converter import ValueConverter

class MappingEngine:
    def __init__(self,rules:tuple[MappingRule,...],excel_row:dict,row_number:int):
        self.rules=rules; self.excel_row=excel_row; self.row_number=row_number
        self.replacements=[]; self.unmatched=[]; self.stats=RunStats(); self._matched_rules=set()

    @staticmethod
    def _norm(v): return str(v).strip().casefold()

    def _match(self,key,rule):
        k=key if rule.case_sensitive else self._norm(key)
        targets=rule.targets if rule.case_sensitive else tuple(self._norm(x) for x in rule.targets)
        return k in targets or (rule.suffix_match and any(k.endswith("_"+t) for t in targets))

    def apply(self,data,dry_run=False):
        self._walk(data,"$",dry_run)
        self._finalize_unmatched()
        return data

    def _walk(self,node,path,dry_run):
        self.stats.visited+=1
        if isinstance(node,dict):
            for key in list(node.keys()):
                p=f"{path}.{key}"
                active=[]
                for rule in self.rules:
                    val=self.excel_row.get(rule.excel_column)
                    if val in (None,""): continue
                    if self._match(key,rule): active.append((rule,val))
                if len(active)>1:
                    self.stats.collisions+=1
                    raise MappingError(f"Mapping collision at {p}: "+", ".join(r.name for r,_ in active))
                if active:
                    rule,val=active[0]; self._matched_rules.add(rule.name); old=node[key]
                    try: new=ValueConverter.convert(val,old,rule.conversion)
                    except MappingError:
                        self.stats.conversion_failures+=1
                        raise
                    if old==new: self.stats.unchanged_matches+=1
                    else:
                        self.replacements.append(Replacement(p,key,old,new,rule.excel_column,rule.name,self.row_number))
                        self.stats.replacements+=1
                        if not dry_run: node[key]=new
                self._walk(node[key],p,dry_run)
        elif isinstance(node,list):
            for i,item in enumerate(node): self._walk(item,f"{path}[{i}]",dry_run)

    def _finalize_unmatched(self):
        for rule in self.rules:
            val=self.excel_row.get(rule.excel_column)
            if val not in (None,"") and rule.name not in self._matched_rules:
                self.stats.unmatched_rules+=1
                self.unmatched.append(UnmatchedField(rule.excel_column,val,"No matching JSON key found",self.row_number))
