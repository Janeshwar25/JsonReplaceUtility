import csv
from pathlib import Path
from .json_reader import JsonReader
from .excel_reader import ExcelReader
from .preflight import Preflight

class MappingAudit:
    @staticmethod
    def generate(json_path, excel_path, sheet, rules, output):
        data=JsonReader.load(json_path)
        reader=ExcelReader(excel_path,sheet)
        row=reader.read_row(2)
        inventory=Preflight.key_inventory(data)
        output.parent.mkdir(parents=True,exist_ok=True)
        with output.open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f)
            w.writerow(["excel_column","excel_value","json_target","occurrences","status"])
            for rule in rules:
                value=row.get(rule.excel_column)
                for target in rule.targets:
                    n=inventory.get(target,0)
                    w.writerow([rule.excel_column,value,target,n,"MATCHED" if n else "NOT_FOUND"])
