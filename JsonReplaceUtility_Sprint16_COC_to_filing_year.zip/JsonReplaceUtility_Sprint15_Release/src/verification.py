from collections import Counter

class VerificationResult:
    def __init__(self):
        self.structure_preserved=False
        self.key_counts_preserved=False
        self.changed_paths=[]
        self.missing_paths=[]
        self.added_paths=[]
        self.type_changes=[]
        self.value_changes=[]

def _walk(node,path="$",out=None):
    if out is None: out={}
    if isinstance(node,dict):
        out[path]=("dict",)
        for k,v in node.items(): _walk(v,f"{path}.{k}",out)
    elif isinstance(node,list):
        out[path]=("list",len(node))
        for i,v in enumerate(node): _walk(v,f"{path}[{i}]",out)
    else:
        out[path]=("scalar",type(node).__name__,node)
    return out

def _key_counts(paths):
    counts=Counter()
    for p in paths:
        if p=="$": continue
        if "." in p:
            key=p.rsplit(".",1)[-1]
        else:
            continue
        if "[" not in key:
            counts[key]+=1
    return counts

def verify(before,after):
    result=VerificationResult()
    a=_walk(before); b=_walk(after)
    a_paths=set(a); b_paths=set(b)
    result.missing_paths=sorted(a_paths-b_paths)
    result.added_paths=sorted(b_paths-a_paths)
    result.structure_preserved=(not result.missing_paths and not result.added_paths)
    result.key_counts_preserved=_key_counts(a_paths)==_key_counts(b_paths)

    for p in sorted(a_paths & b_paths):
        # Only container type changes are structural/type failures.
        a_kind=a[p][0]; b_kind=b[p][0]
        if a_kind != b_kind:
            result.type_changes.append((p,a[p],b[p]))
        elif a_kind=="list" and a[p][1] != b[p][1]:
            result.type_changes.append((p,a[p],b[p]))
        if a_kind=="scalar" and b_kind=="scalar" and a[p][2]!=b[p][2]:
            result.value_changes.append((p,a[p][2],b[p][2]))
    result.changed_paths=[x[0] for x in result.value_changes]
    return result
