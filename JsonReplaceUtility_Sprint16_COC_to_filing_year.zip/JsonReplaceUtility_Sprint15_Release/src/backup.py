from pathlib import Path
from datetime import datetime
import shutil

class Backup:
    @staticmethod
    def create(source:Path,folder:Path):
        folder.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        target=folder/f"{source.stem}_{stamp}{source.suffix}"
        shutil.copy2(source,target); return target
