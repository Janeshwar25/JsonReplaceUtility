import json
from pathlib import Path
from .exceptions import ConfigurationError
from .models import MappingRule

class Config:
    def __init__(self,root:Path):
        self.root=root
        self.settings=self._load(root/"config"/"settings.json")
        raw=self._load(root/"config"/"mapping.json")
        try:
            self.rules=tuple(
                MappingRule(
                    name=r["name"], excel_column=r["excel"],
                    targets=tuple(r["targets"]),
                    suffix_match=bool(r.get("suffix_match",False)),
                    case_sensitive=bool(r.get("case_sensitive",False)),
                    conversion=r.get("conversion","match_existing")
                ) for r in raw["rules"]
            )
        except (KeyError,TypeError) as exc:
            raise ConfigurationError(f"Invalid mapping configuration: {exc}") from exc
        self._validate_unique_rule_names()

    def _validate_unique_rule_names(self):
        names=[r.name for r in self.rules]
        if len(names)!=len(set(names)):
            raise ConfigurationError("Duplicate mapping rule name found")

    @staticmethod
    def _load(path):
        try: return json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc: raise ConfigurationError(f"Cannot load {path}: {exc}") from exc
