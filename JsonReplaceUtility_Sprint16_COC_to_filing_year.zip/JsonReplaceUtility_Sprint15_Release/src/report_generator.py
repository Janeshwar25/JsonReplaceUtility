import csv,html
from pathlib import Path

class ReportGenerator:
    @staticmethod
    def replacements_csv(path,records):
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f); w.writerow(["row_number","path","key","old_value","new_value","excel_column","rule"])
            for r in records: w.writerow([r.row_number,r.path,r.key,r.old_value,r.new_value,r.excel_column,r.rule])

    @staticmethod
    def unmatched_csv(path,records):
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f); w.writerow(["row_number","excel_column","value","reason"])
            for r in records: w.writerow([r.row_number,r.excel_column,r.value,r.reason])

    @staticmethod
    def replacements_html(path,records,stats):
        path.parent.mkdir(parents=True,exist_ok=True)
        rows="".join(
            f"<tr><td>{html.escape(str(r.row_number))}</td><td>{html.escape(r.path)}</td>"
            f"<td>{html.escape(r.key)}</td><td>{html.escape(str(r.old_value))}</td>"
            f"<td>{html.escape(str(r.new_value))}</td><td>{html.escape(r.excel_column)}</td>"
            f"<td>{html.escape(r.rule)}</td></tr>" for r in records)
        doc=f"""<!doctype html><html><head><meta charset="utf-8"><title>JSON Replacement Report</title>
<style>body{{font-family:Arial,sans-serif;margin:30px}}table{{border-collapse:collapse;width:100%}}
th,td{{border:1px solid #ccc;padding:7px;text-align:left}}th{{background:#eee}}</style></head><body>
<h1>JSON Replacement Report</h1>
<p>Visited: {stats.visited} | Replacements: {stats.replacements} | Unmatched: {stats.unmatched_rules}</p>
<table><thead><tr><th>Row</th><th>JSON Path</th><th>Key</th><th>Old</th><th>New</th><th>Excel Column</th><th>Rule</th></tr></thead>
<tbody>{rows}</tbody></table></body></html>"""
        path.write_text(doc,encoding="utf-8")

    @staticmethod
    def batch(path,records):
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f); w.writerow(["row_number","status","replacements","unmatched_rules","output_file","error"]); w.writerows(records)

    @staticmethod
    def preflight(path,records):
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f); w.writerow(["rule","excel_column","target_key","occurrences","status"]); w.writerows(records)

    @staticmethod
    def verification(path,result):
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open("w",newline="",encoding="utf-8") as f:
            w=csv.writer(f)
            w.writerow(["check","status","details"])
            w.writerow(["structure_preserved","PASS" if result.structure_preserved else "FAIL",len(result.missing_paths)+len(result.added_paths)])
            w.writerow(["key_counts_preserved","PASS" if result.key_counts_preserved else "FAIL",""])
            w.writerow(["added_paths","PASS" if not result.added_paths else "FAIL",len(result.added_paths)])
            w.writerow(["missing_paths","PASS" if not result.missing_paths else "FAIL",len(result.missing_paths)])
            w.writerow(["type_changes","PASS" if not result.type_changes else "FAIL",len(result.type_changes)])
            w.writerow(["value_changes", "INFO", len(result.value_changes)])
            if result.added_paths:
                for p in result.added_paths: w.writerow(["added_path","FAIL",p])
            if result.missing_paths:
                for p in result.missing_paths: w.writerow(["missing_path","FAIL",p])
            if result.type_changes:
                for p,a,b in result.type_changes: w.writerow(["type_change","FAIL",f"{p}: {a} -> {b}"])
