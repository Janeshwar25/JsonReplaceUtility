from datetime import datetime,date
from dateutil.parser import parse as parse_date
from .exceptions import MappingError

class ValueConverter:
    @staticmethod
    def convert(value,existing,mode="match_existing"):
        if mode=="string": return str(value)
        if mode=="match_existing":
            if existing is None: return value
            if isinstance(existing,bool):
                text=str(value).strip().casefold()
                if text in {"true","1","yes","y"}: return True
                if text in {"false","0","no","n"}: return False
                raise MappingError(f"Cannot convert {value!r} to boolean")
            if isinstance(existing,int) and not isinstance(existing,bool):
                try: return int(value)
                except (TypeError,ValueError) as exc: raise MappingError(f"Cannot convert {value!r} to int") from exc
            if isinstance(existing,float):
                try: return float(value)
                except (TypeError,ValueError) as exc: raise MappingError(f"Cannot convert {value!r} to float") from exc
            if isinstance(existing,str):
                return str(value)
            return value
        if mode=="date": return ValueConverter._date(value)
        if mode=="int":
            try: return int(value)
            except Exception as exc: raise MappingError(f"Cannot convert {value!r} to int") from exc
        if mode=="float":
            try: return float(value)
            except Exception as exc: raise MappingError(f"Cannot convert {value!r} to float") from exc
        raise MappingError(f"Unknown conversion mode: {mode}")
    @staticmethod
    def _date(value):
        if isinstance(value,(datetime,date)): return value.strftime("%Y-%m-%d")
        try: return parse_date(str(value),dayfirst=False).strftime("%Y-%m-%d")
        except Exception as exc: raise MappingError(f"Cannot convert {value!r} to date") from exc
