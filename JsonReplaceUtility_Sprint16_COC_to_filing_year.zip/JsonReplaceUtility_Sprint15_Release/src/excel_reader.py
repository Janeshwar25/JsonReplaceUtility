from pathlib import Path
from datetime import datetime,date
import math
import openpyxl
from .exceptions import ExcelError

class ExcelReader:
    def __init__(self,path:Path,sheet:str): self.path,self.sheet=path,sheet
    def _workbook(self):
        if not self.path.exists(): raise ExcelError(f"Excel file not found: {self.path}")
        try: return openpyxl.load_workbook(self.path,read_only=True,data_only=True)
        except Exception as exc: raise ExcelError(f"Cannot open Excel workbook: {exc}") from exc
    def _headers(self,ws):
        row=next(ws.iter_rows(min_row=1,max_row=1,values_only=True),None)
        if row is None: raise ExcelError("Excel sheet has no header row")
        out=[]; seen=set()
        for v in row:
            if v is None: out.append(None); continue
            name=str(v).strip()
            if name in seen: raise ExcelError(f"Duplicate Excel column: {name}")
            seen.add(name); out.append(name)
        return out
    def iter_rows(self,start_row=2):
        wb=self._workbook()
        try:
            if self.sheet not in wb.sheetnames: raise ExcelError(f"Sheet not found: {self.sheet}")
            ws=wb[self.sheet]; headers=self._headers(ws)
            for n,values in enumerate(ws.iter_rows(min_row=max(2,start_row),values_only=True),start=max(2,start_row)):
                if not any(v is not None and v!="" for v in values): continue
                yield n,{h:self._normalize(v) for h,v in zip(headers,values) if h is not None}
        finally: wb.close()
    def read_row(self,row_number):
        for n,row in self.iter_rows(row_number):
            if n==row_number: return row
        raise ExcelError(f"Excel row {row_number} not found or empty")
    @staticmethod
    def _normalize(v):
        if isinstance(v,(datetime,date)): return v.strftime("%Y-%m-%d")
        if isinstance(v,float) and math.isnan(v): return None
        if isinstance(v,float) and v.is_integer(): return int(v)
        return v
