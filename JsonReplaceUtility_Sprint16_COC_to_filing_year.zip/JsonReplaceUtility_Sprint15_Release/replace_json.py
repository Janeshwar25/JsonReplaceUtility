from pathlib import Path
import argparse,copy
from src.config import Config
from src.logger import AppLogger
from src.excel_reader import ExcelReader
from src.json_reader import JsonReader
from src.mapping_engine import MappingEngine
from src.validator import Validator
from src.backup import Backup
from src.report_generator import ReportGenerator
from src.batch_processor import BatchProcessor
from src.preflight import Preflight
from src.mapping_audit import MappingAudit
from src.verification import verify

def single(root,args,cfg,logger):
    source=root/args.input; excel=root/args.excel; output=root/(args.output or cfg.settings["output_file"])
    dry=args.dry_run or bool(cfg.settings.get("dry_run",False))
    original=JsonReader.load(source); working=copy.deepcopy(original)
    row_num=args.row if args.row is not None else int(cfg.settings["excel_row"])
    row=ExcelReader(excel,cfg.settings["excel_sheet"]).read_row(row_num)
    engine=MappingEngine(cfg.rules,row,row_num); engine.apply(working,dry)
    Validator.validate(original,working)
    if cfg.settings.get("fail_on_unmatched",False) and engine.unmatched:
        raise RuntimeError(f"Unmatched mapping rules: {engine.stats.unmatched_rules}")
    ReportGenerator.replacements_csv(root/cfg.settings["report_file"],engine.replacements)
    ReportGenerator.unmatched_csv(root/cfg.settings["unmatched_file"],engine.unmatched)
    ReportGenerator.replacements_html(root/cfg.settings["html_report_file"],engine.replacements,engine.stats)
    verification=verify(original,working)
    ReportGenerator.verification(root/"reports/verification_report.csv",verification)
    if not verification.structure_preserved or not verification.key_counts_preserved or verification.type_changes:
        raise RuntimeError("Final verification failed; output was not written")
    if not dry:
        if cfg.settings.get("create_backup",True): Backup.create(source,root/cfg.settings["backup_dir"])
        JsonReader.save(working,output,bool(cfg.settings.get("pretty_json",True)))
    print(f"Replacements: {engine.stats.replacements}")
    print(f"Unmatched rules: {engine.stats.unmatched_rules}")
    print(f"Conversion failures: {engine.stats.conversion_failures}")
    print("Structure validation: PASSED")
    print(f"Dry run: {dry}")
    print(f"HTML report: {root/cfg.settings['html_report_file']}")
    if not dry: print(f"Output: {output}")

def batch(root,args,cfg,logger):
    reader=ExcelReader(root/args.excel,cfg.settings["excel_sheet"])
    processor=BatchProcessor(root/args.input,reader,cfg,logger)
    results=processor.run(root/cfg.settings["batch_output_dir"],args.start_row,args.dry_run)
    ReportGenerator.batch(root/cfg.settings["batch_report_file"],results)
    print(f"Batch rows processed: {len(results)}")
    print(f"Successful: {sum(r[1]=='SUCCESS' for r in results)}")
    print(f"Failed: {sum(r[1]=='FAILED' for r in results)}")
    print(f"Batch report: {root/cfg.settings['batch_report_file']}")

def preflight(root,cfg):
    data=JsonReader.load(root/"input/input.json")
    ok,rows=Preflight.validate_configuration(data,cfg.rules)
    ReportGenerator.preflight(root/cfg.settings["preflight_file"],rows)
    matched=sum(r[4]=="MATCHED" for r in rows)
    missing=sum(r[4]=="NOT_FOUND" for r in rows)
    print(f"Preflight targets checked: {len(rows)}")
    print(f"Matched targets: {matched}")
    print(f"Not found: {missing}")
    print(f"Report: {root/cfg.settings['preflight_file']}")
    return ok

def main():
    root=Path(__file__).resolve().parent
    p=argparse.ArgumentParser(description="Enterprise JSON replacement utility")
    p.add_argument("--input",default="input/input.json")
    p.add_argument("--excel",default="input/OBMDataInput.xlsx")
    p.add_argument("--output")
    p.add_argument("--row",type=int)
    p.add_argument("--batch",action="store_true")
    p.add_argument("--start-row",type=int,default=2)
    p.add_argument("--dry-run",action="store_true")
    p.add_argument("--preflight",action="store_true")
    p.add_argument("--audit",action="store_true")
    p.add_argument("--verify",action="store_true",help="Verify input JSON against an already generated output JSON")
    args=p.parse_args()
    cfg=Config(root); logger=AppLogger(root/cfg.settings["log_file"]); logger.info("Run started")
    if args.verify:
        before=JsonReader.load(root/args.input)
        output=root/(args.output or cfg.settings["output_file"])
        after=JsonReader.load(output)
        vr=verify(before,after)
        ReportGenerator.verification(root/"reports/verification_report.csv",vr)
        print(f"Structure preserved: {vr.structure_preserved}")
        print(f"Key counts preserved: {vr.key_counts_preserved}")
        print(f"Added paths: {len(vr.added_paths)}")
        print(f"Missing paths: {len(vr.missing_paths)}")
        print(f"Type changes: {len(vr.type_changes)}")
        print(f"Value changes: {len(vr.value_changes)}")
    elif args.preflight:
        preflight(root,cfg)
    elif args.audit:
        MappingAudit.generate(root/args.input, root/args.excel, cfg.settings["excel_sheet"], cfg.rules, root/"reports/mapping_audit.csv")
        print("Mapping audit: reports/mapping_audit.csv")
    elif args.batch:
        batch(root,args,cfg,logger)
    else:
        single(root,args,cfg,logger)
    logger.info("Run completed")

if __name__=="__main__": main()
