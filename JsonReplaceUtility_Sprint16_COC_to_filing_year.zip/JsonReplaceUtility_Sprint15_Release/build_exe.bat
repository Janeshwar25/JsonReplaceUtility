@echo off
setlocal
cd /d "%~dp0"
python -m PyInstaller --noconfirm --clean --onefile --name JsonReplaceUtility replace_json.py
if errorlevel 1 exit /b 1
echo EXE created at dist\JsonReplaceUtility.exe
