# Sprint 14 Release Candidate

Clean deployment package.

Includes recursive replacement, explicit mappings, nested arrays/objects,
audit/preflight, dry-run, backup, atomic output, structural verification,
reports, logging, batch mode, Windows launchers and PyInstaller configuration.

The final Windows EXE must be built and smoke-tested on Windows using `build_exe.bat`.
Sprint 13 automated QA: 11 tests passed.


## Sprint 15 mapping update
- Added `COC Year` -> `filing_year` mapping.
- Existing recursive replacement behavior applies to every matching `filing_year` field in the JSON.
