@echo off
setlocal
cd /d "%~dp0"
python replace_json.py %*
set "EXITCODE=%ERRORLEVEL%"
echo.
if "%EXITCODE%"=="0" (
  echo SUCCESS - Utility completed.
) else (
  echo FAILED - Exit code %EXITCODE%.
)
echo.
exit /b %EXITCODE%
