# -*- mode: python ; coding: utf-8 -*-
from PyInstaller.utils.hooks import collect_submodules
hiddenimports = collect_submodules("src")
a = Analysis(
    ["replace_json.py"], pathex=["."], binaries=[],
    datas=[("config", "config")], hiddenimports=hiddenimports,
    hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, a.binaries, a.datas, [],
    name="JsonReplaceUtility", debug=False, bootloader_ignore_signals=False,
    strip=False, upx=True, console=True,
)
