from .models import Replacement
from .exceptions import MappingError
from .null_overrides import _parse_path


def _get_path(data, path):
    node = data
    for token in _parse_path(path):
        node = node[token]
    return node


def _set_path(data, path, value):
    tokens = _parse_path(path)
    node = data
    for token in tokens[:-1]:
        node = node[token]
    node[tokens[-1]] = value


def apply_copy_paths(data, rules, engine=None, row_number=0):
    """Copy values from configured source JSON paths to target paths."""
    for rule in rules or []:
        target = rule.get("target")
        source = rule.get("source")
        if not target or not source:
            raise MappingError(f"Invalid copy_value_paths rule: {rule!r}")
        try:
            source_value = _get_path(data, source)
            old_value = _get_path(data, target)
            if old_value != source_value:
                _set_path(data, target, source_value)
                if engine is not None:
                    engine.replacements.append(
                        Replacement(
                            path=target,
                            key=target.rsplit(".", 1)[-1],
                            old_value=old_value,
                            new_value=source_value,
                            excel_column="<copied-from-json>",
                            rule=f"copy_from:{source}",
                            row_number=row_number,
                        )
                    )
                    engine.stats.replacements += 1
        except (KeyError, IndexError, TypeError) as exc:
            raise MappingError(
                f"Configured copy_value_paths source/target not found: {source} -> {target}"
            ) from exc
    return data
