# JsonReplaceUtility — Flask + BAT + ACCELQ

## Architecture

ACCELQ -> HTTP POST -> Flask (`127.0.0.1:5000`) -> `run_utility.bat` -> `replace_json.py` -> existing JSON replacement/report flow.

The Flask layer is only an execution wrapper. The JSON replacement/mapping logic remains in the existing utility.

## Start Flask

PowerShell command 1:

```powershell
cd "C:\path\to\JsonReplaceUtility_Sprint18_ACCELQ_Ready"
```

PowerShell command 2:

```powershell
python -m pip install -r requirements.txt
```

PowerShell command 3:

```powershell
python validator_api.py
```

The API listens on:

`http://127.0.0.1:5000`

## Local POST test

In a second PowerShell window:

```powershell
Invoke-RestMethod `
  -Uri "http://127.0.0.1:5000/run-json-replace" `
  -Method POST `
  -ContentType "application/json" `
  -Body "{}"
```

## Optional request parameters

The empty body `{}` uses the utility's existing defaults. The API also accepts:

```json
{
  "input": "input/input.json",
  "excel": "input/OBMDataInput.xlsx",
  "output": "output/updated.json",
  "row": 2,
  "dry_run": false,
  "preflight": false,
  "audit": false,
  "batch": false,
  "start_row": 2,
  "verify": false
}
```

## Response

Successful execution returns HTTP 200 and:

```json
{
  "returncode": 0,
  "status": "success",
  "success": true,
  "report_file": "reports/replacement_report.html",
  "report_files": [
    "reports/replacement_report.html",
    "reports/replacement_report.csv",
    "reports/unmatched_fields.csv",
    "reports/verification_report.csv"
  ],
  "output_file": "output/updated.json",
  "stdout": "...",
  "stderr": ""
}
```

If the utility itself fails, Flask still returns HTTP 200 because the utility execution completed; AccelQ must assert `returncode == 0` and `status == "success"`. The actual utility exit code is preserved.

## Exit codes

- `0` success
- `10` validation error
- `11` configuration error
- `12` input/JSON/Excel error
- `13` mapping error
- `14` output/file error
- `99` unexpected error
