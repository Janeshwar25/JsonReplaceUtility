# ACCELQ Integration — Flask API approach

## 1. Start the local Flask API

On the Windows machine where the ACCELQ Agent is running:

```powershell
cd "C:\path\to\JsonReplaceUtility_Sprint18_ACCELQ_Ready"
python -m pip install -r requirements.txt
python validator_api.py
```

The API stays on:

```text
http://127.0.0.1:5000
```

## 2. ACCELQ REST call

Method:

```text
POST
```

URL:

```text
http://127.0.0.1:5000/run-json-replace
```

Header:

```text
Content-Type: application/json
```

Body:

```json
{}
```

## 3. ACCELQ assertions

Assert:

```text
HTTP status == 200
response.returncode == 0
response.status == "success"
response.success == true
response.report_file is not empty
response.output_file is not empty
```

## 4. Optional parameters

The API supports `input`, `excel`, `output`, `row`, `start_row`, `dry_run`, `preflight`, `audit`, `batch`, and `verify`. Empty `{}` is recommended initially because it uses the utility's existing defaults.

## 5. Important machine requirement

Flask and the ACCELQ Agent must run on the same Windows machine. `127.0.0.1` refers to that machine.

The utility itself still works independently through `run_utility.bat`.
