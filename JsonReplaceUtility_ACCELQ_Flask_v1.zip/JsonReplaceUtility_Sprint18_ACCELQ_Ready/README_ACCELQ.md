# ACCELQ-ready deployment

Preferred execution architecture:

`ACCELQ -> Flask -> run_utility.bat -> replace_json.py`

Start Flask on the same Windows machine as the ACCELQ Agent:

```powershell
cd "C:\path\to\JsonReplaceUtility_Sprint18_ACCELQ_Ready"
python -m pip install -r requirements.txt
python validator_api.py
```

Endpoint:

```text
POST http://127.0.0.1:5000/run-json-replace
```

Body:

```json
{}
```

The Flask API waits for the BAT/utility to finish, captures stdout/stderr, preserves the utility exit code, and returns the existing report/output locations.

The EXE build remains available separately through `build_exe.bat`, but it is not required for the Python + BAT + Flask integration.
