from pathlib import Path
import json
import subprocess
from flask import Flask, jsonify, request

app = Flask(__name__)

ROOT = Path(__file__).resolve().parent
BAT_FILE = ROOT / "run_utility.bat"
CONFIG_FILE = ROOT / "config" / "settings.json"


def load_settings():
    with CONFIG_FILE.open("r", encoding="utf-8") as f:
        return json.load(f)


def relative_to_root(path_value):
    if not path_value:
        return None
    path = Path(path_value).resolve()
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def build_command(payload):
    command = []

    # Body {} keeps the existing utility defaults.
    # Optional values are passed only when explicitly supplied by AccelQ.
    if payload.get("input"):
        command += ["--input", str(payload["input"])]
    if payload.get("excel"):
        command += ["--excel", str(payload["excel"])]
    if payload.get("output"):
        command += ["--output", str(payload["output"])]
    if payload.get("row") is not None:
        command += ["--row", str(payload["row"])]
    if payload.get("start_row") is not None:
        command += ["--start-row", str(payload["start_row"])]

    for flag in ("batch", "dry_run", "preflight", "audit", "verify"):
        if payload.get(flag) is True:
            command.append("--" + flag.replace("_", "-"))

    return command


def result_paths(payload):
    settings = load_settings()

    output_value = payload.get("output") or settings.get("output_file")
    output_path = Path(output_value)
    if not output_path.is_absolute():
        output_path = ROOT / output_path

    if payload.get("audit"):
        primary_report = ROOT / "reports" / "mapping_audit.csv"
        report_files = [primary_report]
    elif payload.get("preflight"):
        primary_report = ROOT / settings["preflight_file"]
        report_files = [primary_report]
    elif payload.get("batch"):
        primary_report = ROOT / settings["batch_report_file"]
        report_files = [primary_report]
    elif payload.get("verify"):
        primary_report = ROOT / settings["verification_file"]
        report_files = [primary_report]
    else:
        primary_report = ROOT / settings["html_report_file"]
        report_files = [
            primary_report,
            ROOT / settings["report_file"],
            ROOT / settings["unmatched_file"],
            ROOT / settings["verification_file"],
        ]

    existing_reports = [p for p in report_files if p.exists()]

    # Dry-run intentionally does not create the JSON output.
    output_result = None
    if not payload.get("dry_run") and not payload.get("audit") and not payload.get("preflight") and not payload.get("verify"):
        if payload.get("batch"):
            output_result = relative_to_root(ROOT / settings["batch_output_dir"])
        elif output_path.exists():
            output_result = relative_to_root(output_path)
        else:
            # Return the expected path even if execution failed before writing it.
            output_result = relative_to_root(output_path)

    return primary_report, existing_reports, output_result


def execute_utility(payload):
    if not BAT_FILE.exists():
        raise FileNotFoundError(f"BAT file not found: {BAT_FILE}")

    command_args = build_command(payload)

    # cmd.exe /d /c CALL is deliberate: it executes the BAT file from any
    # current working directory and preserves the BAT's final exit code.
    command = [
        "cmd.exe",
        "/d",
        "/c",
        "call",
        str(BAT_FILE),
        *command_args,
    ]

    completed = subprocess.run(
        command,
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        shell=False,
    )

    return completed


@app.get("/")
def health():
    return jsonify({
        "service": "JsonReplaceUtility API",
        "status": "running",
        "endpoint": "/run-json-replace",
    })


@app.post("/run-json-replace")
def run_json_replace():
    payload = request.get_json(silent=True)
    if payload is None:
        payload = {}

    if not isinstance(payload, dict):
        return jsonify({
            "returncode": 99,
            "status": "failed",
            "success": False,
            "error": "Request body must be a JSON object",
        }), 400

    try:
        primary_report, report_candidates, output_file = result_paths(payload)
        completed = execute_utility(payload)

        existing_reports = [p for p in report_candidates if p.exists()]
        response = {
            "returncode": completed.returncode,
            "status": "success" if completed.returncode == 0 else "failed",
            "success": completed.returncode == 0,
            "report_file": relative_to_root(primary_report),
            "report_files": [relative_to_root(p) for p in existing_reports],
            "output_file": output_file,
            "stdout": completed.stdout,
            "stderr": completed.stderr,
        }

        # Keep HTTP 200 for a completed utility run, including utility-level
        # failures. AccelQ can then assert returncode == 0/status == success.
        return jsonify(response), 200

    except Exception as exc:
        return jsonify({
            "returncode": 99,
            "status": "failed",
            "success": False,
            "report_file": None,
            "report_files": [],
            "output_file": None,
            "stdout": "",
            "stderr": str(exc),
        }), 500


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
