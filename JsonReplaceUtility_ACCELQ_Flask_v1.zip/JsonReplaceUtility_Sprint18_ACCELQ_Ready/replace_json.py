from pathlib import Path
import argparse,copy,sys
from src.config import Config
from src.logger import AppLogger
from src.excel_reader import ExcelReader
from src.json_reader import JsonReader
from src.mapping_engine import MappingEngine
from src.validator import Validator
from src.backup import Backup
from src.report_generator import ReportGenerator
from src.batch_processor import BatchProcessor
from src.preflight import Preflight
from src.mapping_audit import MappingAudit
from src.verification import verify
from src.exceptions import ConfigurationError, ExcelError, JsonError, MappingError, ValidationError

def single(root,args,cfg,logger):
    source=root/args.input; excel=root/args.excel; output=root/(args.output or cfg.settings["output_file"])
    dry=args.dry_run or bool(cfg.settings.get("dry_run",False))
    original=JsonReader.load(source); working=copy.deepcopy(original)
    row_num=args.row if args.row is not None else int(cfg.settings["excel_row"])
    row=ExcelReader(excel,cfg.settings["excel_sheet"]).read_row(row_num)
    engine=MappingEngine(cfg.rules,row,row_num); engine.apply(working,dry)
    Validator.validate(original,working)
    if cfg.settings.get("fail_on_unmatched",False) and engine.unmatched:
        raise MappingError(f"Unmatched mapping rules: {engine.stats.unmatched_rules}")
    ReportGenerator.replacements_csv(root/cfg.settings["report_file"],engine.replacements)
    ReportGenerator.unmatched_csv(root/cfg.settings["unmatched_file"],engine.unmatched)
    ReportGenerator.replacements_html(root/cfg.settings["html_report_file"],engine.replacements,engine.stats)
    verification=verify(original,working)
    ReportGenerator.verification(root/"reports/verification_report.csv",verification)
    if not verification.structure_preserved or not verification.key_counts_preserved or verification.type_changes:
        raise ValidationError("Final verification failed; output was not written")
    if not dry:
        if cfg.settings.get("create_backup",True): Backup.create(source,root/cfg.settings["backup_dir"])
        JsonReader.save(working,output,bool(cfg.settings.get("pretty_json",True)))
    print(f"Replacements: {engine.stats.replacements}")
    print(f"Unmatched rules: {engine.stats.unmatched_rules}")
    print(f"Conversion failures: {engine.stats.conversion_failures}")
    print("Structure validation: PASSED")
    print(f"Dry run: {dry}")
    print(f"HTML report: {root/cfg.settings['html_report_file']}")
    if not dry: print(f"Output: {output}")

def batch(root,args,cfg,logger):
    reader=ExcelReader(root/args.excel,cfg.settings["excel_sheet"])
    processor=BatchProcessor(root/args.input,reader,cfg,logger)
    results=processor.run(root/cfg.settings["batch_output_dir"],args.start_row,args.dry_run)
    ReportGenerator.batch(root/cfg.settings["batch_report_file"],results)
    print(f"Batch rows processed: {len(results)}")
    print(f"Successful: {sum(r[1]=='SUCCESS' for r in results)}")
    print(f"Failed: {sum(r[1]=='FAILED' for r in results)}")
    print(f"Batch report: {root/cfg.settings['batch_report_file']}")

def preflight(root,cfg):
    data=JsonReader.load(root/"input/input.json")
    ok,rows=Preflight.validate_configuration(data,cfg.rules)
    ReportGenerator.preflight(root/cfg.settings["preflight_file"],rows)
    matched=sum(r[4]=="MATCHED" for r in rows)
    missing=sum(r[4]=="NOT_FOUND" for r in rows)
    print(f"Preflight targets checked: {len(rows)}")
    print(f"Matched targets: {matched}")
    print(f"Not found: {missing}")
    print(f"Report: {root/cfg.settings['preflight_file']}")
    return ok

def application_root():
    # When packaged as a PyInstaller EXE, use the EXE directory for all
    # external input/output/config/report files. During source execution,
    # use the project directory.
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent

def resolve_path(root, value):
    p=Path(value)
    return p if p.is_absolute() else root/p

def main():
    root=application_root()
    p=argparse.ArgumentParser(description="Enterprise JSON replacement utility")
    p.add_argument("--input",default="input/input.json",help="Input JSON path; absolute or relative to utility folder")
    p.add_argument("--excel",default="input/OBMDataInput.xlsx",help="Excel path; absolute or relative to utility folder")
    p.add_argument("--output",help="Output JSON path; absolute or relative to utility folder")
    p.add_argument("--row",type=int)
    p.add_argument("--batch",action="store_true")
    p.add_argument("--start-row",type=int,default=2)
    p.add_argument("--dry-run",action="store_true")
    p.add_argument("--preflight",action="store_true")
    p.add_argument("--audit",action="store_true")
    p.add_argument("--verify",action="store_true",help="Verify input JSON against an already generated output JSON")
    args=p.parse_args()

    # Normalize CLI paths once so ACCELQ can pass absolute paths safely.
    args.input = str(resolve_path(root, args.input))
    args.excel = str(resolve_path(root, args.excel))
    if args.output:
        args.output = str(resolve_path(root, args.output))

    cfg=None
    logger=None
    try:
        cfg=Config(root)
        logger=AppLogger(root/cfg.settings["log_file"])
        logger.info("Run started")

        if args.verify:
            before=JsonReader.load(root/args.input)
            output=root/(args.output or cfg.settings["output_file"])
            after=JsonReader.load(output)
            vr=verify(before,after)
            ReportGenerator.verification(root/"reports/verification_report.csv",vr)
            print(f"Structure preserved: {vr.structure_preserved}")
            print(f"Key counts preserved: {vr.key_counts_preserved}")
            print(f"Added paths: {len(vr.added_paths)}")
            print(f"Missing paths: {len(vr.missing_paths)}")
            print(f"Type changes: {len(vr.type_changes)}")
            print(f"Value changes: {len(vr.value_changes)}")
            if not vr.structure_preserved or not vr.key_counts_preserved or vr.type_changes:
                raise ValidationError("Verification failed")
        elif args.preflight:
            if not preflight(root,cfg):
                raise ValidationError("Preflight failed: one or more mapping targets were not found")
        elif args.audit:
            MappingAudit.generate(root/args.input, root/args.excel, cfg.settings["excel_sheet"], cfg.rules, root/"reports/mapping_audit.csv")
            print("Mapping audit: reports/mapping_audit.csv")
        elif args.batch:
            batch(root,args,cfg,logger)
        else:
            single(root,args,cfg,logger)

        logger.info("Run completed")
        return 0

    except ConfigurationError as exc:
        if logger: logger.error(str(exc))
        print(f"ERROR [11] CONFIGURATION: {exc}", file=sys.stderr)
        return 11
    except ValidationError as exc:
        if logger: logger.error(str(exc))
        print(f"ERROR [10] VALIDATION: {exc}", file=sys.stderr)
        return 10
    except MappingError as exc:
        if logger: logger.error(str(exc))
        print(f"ERROR [13] MAPPING: {exc}", file=sys.stderr)
        return 13
    except (ExcelError, JsonError) as exc:
        if logger: logger.error(str(exc))
        message=str(exc)
        # JsonError is used for both reading and saving. Saving is an output
        # failure; loading is an input failure.
        code=14 if message.startswith("Cannot save") else 12
        label="OUTPUT/FILE" if code == 14 else "INPUT"
        print(f"ERROR [{code}] {label}: {exc}", file=sys.stderr)
        return code
    except OSError as exc:
        if logger: logger.error(str(exc))
        print(f"ERROR [14] OUTPUT/FILE: {exc}", file=sys.stderr)
        return 14
    except Exception as exc:
        if logger: logger.error(f"Unexpected error: {exc}")
        print(f"ERROR [99] UNEXPECTED: {exc}", file=sys.stderr)
        return 99



if __name__=="__main__":
    sys.exit(main())
