@echo off
setlocal
cd /d "%~dp0"

REM Requires validator_api.py to be running in another terminal.
python -c "import urllib.request; req=urllib.request.Request('http://127.0.0.1:5000/run-json-replace', data=b'{}', headers={'Content-Type':'application/json'}, method='POST'); print(urllib.request.urlopen(req).read().decode())"
set "EXITCODE=%ERRORLEVEL%"
endlocal & exit /b %EXITCODE%
