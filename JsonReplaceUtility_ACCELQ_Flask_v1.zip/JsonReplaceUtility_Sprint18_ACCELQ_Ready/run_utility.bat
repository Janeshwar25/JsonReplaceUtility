@echo off
setlocal
cd /d "%~dp0"

REM Always make the project root importable when running from Windows/AccelQ.
set "PYTHONPATH=%~dp0;%PYTHONPATH%"

python "%~dp0replace_json.py" %*
set "EXITCODE=%ERRORLEVEL%"

echo.
if "%EXITCODE%"=="0" (
  echo SUCCESS - Utility completed.
) else (
  echo FAILED - Exit code %EXITCODE%.
)
echo.

endlocal & exit /b %EXITCODE%
