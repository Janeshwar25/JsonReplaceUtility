@echo off
setlocal
cd /d "%~dp0"
python -m PyInstaller --noconfirm --clean --onefile --name JsonReplaceUtility --add-data "config;config" replace_json.py
if errorlevel 1 exit /b 1
copy /Y "dist\JsonReplaceUtility.exe" ".\JsonReplaceUtility.exe" >nul
if errorlevel 1 exit /b 1
echo.
echo EXE created: %CD%\JsonReplaceUtility.exe
echo.
