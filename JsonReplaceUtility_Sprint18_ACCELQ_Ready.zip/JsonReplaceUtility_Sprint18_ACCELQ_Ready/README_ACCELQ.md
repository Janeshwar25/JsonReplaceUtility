# ACCELQ-ready deployment

This release is designed for ACCELQ to invoke the utility as a Windows EXE.

### One-time Windows build

```bat
install.bat
build_exe.bat
```

After the build, use `JsonReplaceUtility.exe` from the utility root. ACCELQ does not need Python or the Python source code on the execution machine once the EXE has been built.

### ACCELQ action

Use **Execute Windows System Command** and pass an absolute EXE path. The utility supports `--input`, `--excel`, and `--output` as absolute paths, which is recommended for test automation.
