@echo off
setlocal
cd /d "%~dp0"
python replace_json.py --input "input\input.json" --excel "input\OBMDataInput.xlsx" --output "output\accelq_test.json" --dry-run
exit /b %ERRORLEVEL%
