# ACCELQ Integration — EXE approach

ACCELQ should invoke the Windows executable through **Execute Windows System Command** on the ACCELQ Agent machine.

## 1. Build once on Windows

Run:

```bat
install.bat
build_exe.bat
```

This creates:

```text
JsonReplaceUtility.exe
```

in the utility root folder.

## 2. Recommended ACCELQ command

Use the ACCELQ command:

```text
Execute Windows System Command
```

Point it to the EXE with an absolute path.

Example:

```bat
"C:\Users\jchowdha\JsonReplaceUtility\JsonReplaceUtility.exe"
```

## 3. Parameterized ACCELQ execution

The EXE accepts absolute paths, so ACCELQ can pass test-specific files:

```bat
"C:\Users\jchowdha\JsonReplaceUtility\JsonReplaceUtility.exe" --input "C:\TestData\input.json" --excel "C:\TestData\OBMDataInput.xlsx" --output "C:\TestData\output\updated.json"
```

Relative paths are also supported and are resolved relative to the EXE folder.

## 4. Useful modes

Preflight:

```bat
"C:\Users\jchowdha\JsonReplaceUtility\JsonReplaceUtility.exe" --preflight
```

Dry run:

```bat
"C:\Users\jchowdha\JsonReplaceUtility\JsonReplaceUtility.exe" --input "C:\TestData\input.json" --excel "C:\TestData\OBMDataInput.xlsx" --output "C:\TestData\output\updated.json" --dry-run
```

Actual replacement:

```bat
"C:\Users\jchowdha\JsonReplaceUtility\JsonReplaceUtility.exe" --input "C:\TestData\input.json" --excel "C:\TestData\OBMDataInput.xlsx" --output "C:\TestData\output\updated.json"
```

## 5. Recommended ACCELQ flow

1. Prepare/copy JSON and Excel test data.
2. Run `--preflight`.
3. Optionally run `--dry-run` for validation.
4. Run the EXE for actual replacement.
5. Verify `output\updated.json` from ACCELQ.

## 6. Important deployment rule

The EXE and its `config` folder should be deployed together. The utility writes reports/logs/backup relative to its EXE folder unless an absolute output path is supplied.

The ACCELQ Agent must be installed/running on the Windows machine where the EXE and test data are accessible.
